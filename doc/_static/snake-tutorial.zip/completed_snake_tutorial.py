import random
import pygame

import serge.visual
import serge.sound
import serge.engine
import serge.actor
import serge.blocks.visualblocks
import serge.blocks.utils
import serge.blocks.directions
import serge.blocks.behaviours
import serge.blocks.actors
    
class Snake(serge.actor.CompositeActor):
    """Represents the snake"""
    
    def __init__(self):
        """Initialise the snake"""
        super(Snake, self).__init__('snake', 'snake-head')
        self.visual = serge.blocks.visualblocks.Circle(16, (0,255,0))
        self.setSpriteName('head')
        self.setLayerName('middle')
        self.current_direction = serge.blocks.directions.N
        self.is_dying = False

    def addedToWorld(self, world):
        """The snake was added to the world"""
        super(Snake, self).addedToWorld(world)
        #
        self.keyboard = serge.engine.CurrentEngine().getKeyboard()
        self.manager = serge.blocks.behaviours.BehaviourManager('manager', 'behaviour-manager')
        self.world = world
        world.addActor(self.manager)
        #
        # Text to display when the game is over
        self.restart_text = serge.blocks.utils.addVisualActorToWorld(world, 'text', 'restart',
            serge.visual.Text('Game Over - Press ENTER to restart', (255, 255, 255), font_size=20),
            layer_name='front',
            center_position=(400, 300))
        self.restart_text.visible = False
        #
        # A background for the game
        self.bg = serge.blocks.utils.addVisualActorToWorld(world, 'bg', 'bg',
            serge.blocks.visualblocks.Rectangle((800, 600), (0,0,255)),
            layer_name='back',
            center_position=(400, 300))
        #
        # Text to show the score
        self.score = serge.blocks.utils.addActorToWorld(world, 
            serge.blocks.actors.NumericText('text', 'score', 'Score: %04d', 
                (255, 255, 255), font_size=20, font_name='scores', value=0, align='left'),
            layer_name='front',
            center_position=(120, 30))
        
    def updateActor(self, interval, world):
        """Update the snake"""
        super(Snake, self).updateActor(interval, world)
        #
        # Quit if requested
        if self.keyboard.isClicked(pygame.K_ESCAPE):
            serge.engine.CurrentEngine().stop()
        #
        # Move the head
        if self.keyboard.isClicked(pygame.K_LEFT):
            rotation = +90
        elif self.keyboard.isClicked(pygame.K_RIGHT):
            rotation = -90
        else:
            rotation = 0
        #
        # Change direction
        if rotation:
            current_angle = serge.blocks.directions.getAngleFromCardinal(self.current_direction)
            self.current_direction = serge.blocks.directions.getCardinalFromAngle(current_angle+rotation)
            self.visual.setAngle(current_angle+rotation)
        #
        # Move
        if not self.is_dying:
            offset = 5*serge.blocks.directions.getVectorFromCardinal(self.current_direction)
            self.move(*offset)
            #
            # Adding random rocks
            if random.random() < 0.01:
                self.addRock()
            #
            # Add a new segment if needed
            if not self.getChildren() or self.getDistanceFrom(self.getChildren()[-1]) > 16:
                self.addSegment()
            #
            # Check if we hit the body
            if self.hitBody() or self.offScreen() or self.hitRock():
                self.initiateDeathAnimation()
            #
            # Increase score
            self.score.value += interval/1000.0
        elif self.animation.isComplete():
            if self.keyboard.isClicked(pygame.K_KP_ENTER) or self.keyboard.isClicked(pygame.K_RETURN):
                self.restartGame()
            
    def addSegment(self):
        """Add a new body segment"""
        segment = serge.actor.Actor('segment')
        segment.setSpriteName('tail')
        segment.setLayerName('middle')
        segment.moveTo(self.x, self.y)
        self.addChild(segment)
        serge.sound.Sounds.play('new-body')

    def addRock(self):
        """Add a rock to the screen"""
        position = (random.randrange(0, 800), random.randrange(0, 600))
        rock = serge.actor.Actor('rock')
        rock.setSpriteName('rock')
        rock.setLayerName('middle')
        rock.moveTo(*position)
        rock.setAngle(random.randrange(0, 360))
        rock.linkEvent(serge.events.E_LEFT_CLICK, self.destroyRock, rock)
        self.world.addActor(rock)

    def hitBody(self):
        """Return True if the head has hit the body
        
        Look to see if we overlap with any body segment except the last
        (we are allowed to overlap the last since we just put it down)
        
        """
        for segment in self.getChildren()[:-1]:
            if self.getDistanceFrom(segment) < 16:
                return True
        return False
        
    def hitRock(self):
        """Return True if we hit a rock"""
        for rock in self.world.findActorsByTag('rock'):
            if self.getDistanceFrom(rock) < 16:
                return True
        else:
            return False
            
    def offScreen(self):
        """Return True if we are off the screen"""
        return self.x < 0 or self.x > 800 or self.y < 0 or self.y > 600
        
    def initiateDeathAnimation(self):
        """Begin showing the death of the snake"""
        self.log.info('Snake died!')
        self.animation = self.manager.assignBehaviour(self, 
            serge.blocks.behaviours.TimedCallback(1000/len(self.getChildren()), self.removeTail), 'death-animation')
        self.is_dying = True
        for segment in self.getChildren():
            segment.setSpriteName('red-tail')
        self.setSpriteName('red-head')
        serge.sound.Sounds.play('snake-death')
            
    def removeTail(self, world, actor, interval):
        """Remove part of the tail"""
        self.log.debug('Removing part of the tail')
        if self.getChildren():
            self.removeChild(self.getChildren()[0])
        else:
            self.animation.markComplete()
            self.restart_text.visible = True
            serge.sound.Sounds.getItem('snake-death').fadeout(500)    
    
    def destroyRock(self, obj, rock):
        """Destroy a rock"""
        self.world.removeActor(rock)
        explosion = serge.blocks.actors.AnimateThenDieActor('explosion', 'explosion', 'explosion', 'front')
        explosion.moveTo(rock.x, rock.y)
        self.world.addActor(explosion)
        
    def restartGame(self):
        """Restart the game"""
        self.is_dying = False
        self.restart_text.visible = False
        self.setSpriteName('head')
        self.current_direction = serge.blocks.directions.N
        self.score.value = 0
        self.moveTo(400, 300)
        self.world.clearActorsWithTags(['rock'])
        
        
# Create the engine
engine = serge.blocks.utils.getSimpleSetup(800, 600)
world = engine.getWorld('lab')

# Register sprites
serge.visual.Sprites.setPath('graphics')
serge.visual.Sprites.registerItem('head', 'head.png')
serge.visual.Sprites.registerItem('tail', 'tail.png')
serge.visual.Sprites.registerItem('red-head', 'red-head.png')
serge.visual.Sprites.registerItem('red-tail', 'red-tail.png')
serge.visual.Sprites.registerItem('rock', 'rock.png')
serge.visual.Sprites.registerItem('explosion', 'explosion.png', zoom=0.25,
        w=8, framerate=10, running=True, loop=False, one_direction=True)
        
# Register sounds
serge.sound.Sounds.setPath('sounds')
serge.sound.Sounds.registerItem('new-body', 'bloop.wav')
serge.sound.Sounds.registerItem('snake-death', 'death.wav')

# Register fonts
serge.visual.Fonts.setPath('fonts')
serge.visual.Fonts.registerItem('DEFAULT', 'MedievalSharp.ttf')
serge.visual.Fonts.registerItem('scores', 'PressStart2P.ttf')

# Create the snake
snake = Snake()
world.addActor(snake)
snake.moveTo(400, 300)

# Run the game
engine.run(60)

